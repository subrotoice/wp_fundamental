<div class="sidebar">
	<?php dynamic_sidebar('right_sidebar'); ?>
</div>